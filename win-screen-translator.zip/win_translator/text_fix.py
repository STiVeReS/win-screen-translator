import re
from typing import Dict, List


_RE_SPACES = re.compile(r"[\t\u00A0\u2007\u202F]+")
_RE_MULTI_SPACE = re.compile(r" {2,}")
_RE_WS_AROUND_PUNCT = re.compile(r"\s+([,.;:!?])")
_RE_WS_AFTER_OPEN = re.compile(r"([\(\[\{])\s+")
_RE_WS_BEFORE_CLOSE = re.compile(r"\s+([\)\]\}])")


def _safe_str(x) -> str:
    try:
        return str(x or '')
    except Exception:
        return ''


def _builtin_replacements(aggressive: bool) -> Dict[str, str]:
    # Максимально безпечні штуки (лігатури, пробіли, лапки).
    base = {
        "\u00ad": "",     # soft hyphen
        "\ufeff": "",     # BOM
        "\u200b": "",     # zero width space
        "\u200c": "",
        "\u200d": "",
        "\ufb01": "fi",   # ﬁ
        "\ufb02": "fl",   # ﬂ
        "“": '"',
        "”": '"',
        "„": '"',
        "’": "'",
        "‘": "'",
        "—": "-",
        "–": "-",
        "…": "...",
    }

    if aggressive:
        # Тут вже «обережно, ми люди»: міняємо деякі часто-биті символи.
        base.update({
            "|": "I",
            "¦": "I",
        })

    return base


def _apply_simple_map(text: str, mapping: Dict[str, str]) -> str:
    out = text
    for k, v in (mapping or {}).items():
        if not k:
            continue
        out = out.replace(str(k), str(v))
    return out


def _apply_regex_map(text: str, regex_rules: List[Dict[str, str]]) -> str:
    out = text
    for rule in (regex_rules or []):
        if not isinstance(rule, dict):
            continue
        pat = _safe_str(rule.get('pattern'))
        rep = _safe_str(rule.get('repl'))
        if not pat:
            continue
        try:
            out = re.sub(pat, rep, out)
        except Exception:
            continue
    return out


def normalize_ocr_text(text: str, aggressive: bool) -> str:
    s = _safe_str(text)
    if not s:
        return ''

    # Склеюємо перенос по дефісу: "some-\nthing" -> "something"
    s = s.replace('-\n', '')
    s = s.replace('‐\n', '')

    s = s.replace('\r\n', '\n')
    s = s.replace('\r', '\n')

    s = _apply_simple_map(s, _builtin_replacements(aggressive))

    # Нормалізація пробілів
    s = _RE_SPACES.sub(' ', s)
    s = s.strip()
    s = _RE_MULTI_SPACE.sub(' ', s)

    # Ламаємо "порожні" рядки по одному
    lines = [ln.strip() for ln in s.split('\n')]
    out_lines: List[str] = []
    prev_empty = False
    for ln in lines:
        if not ln:
            if prev_empty:
                continue
            out_lines.append('')
            prev_empty = True
            continue
        prev_empty = False
        out_lines.append(ln)
    return '\n'.join(out_lines).strip()


def normalize_translated_text(text: str, aggressive: bool) -> str:
    s = _safe_str(text)
    if not s:
        return ''

    s = s.replace('\r\n', '\n')
    s = s.replace('\r', '\n')
    s = _apply_simple_map(s, _builtin_replacements(aggressive))
    s = _RE_SPACES.sub(' ', s)
    s = _RE_MULTI_SPACE.sub(' ', s)

    # Трохи косметики з пунктуацією.
    s = _RE_WS_AROUND_PUNCT.sub(r"\1", s)
    s = _RE_WS_AFTER_OPEN.sub(r"\1", s)
    s = _RE_WS_BEFORE_CLOSE.sub(r"\1", s)
    return s.strip()


def postprocess_texts_for_translation(texts: List[str], cfg) -> List[str]:
    enabled = bool(getattr(cfg, 'text_postprocess_enabled', True))
    if not enabled:
        return [(_safe_str(t)).strip() for t in (texts or [])]

    aggressive = bool(getattr(cfg, 'text_postprocess_aggressive', False))
    base_map = {}
    try:
        base_map = dict(getattr(cfg, 'text_replacements', {}) or {})
    except Exception:
        base_map = {}

    regex_rules = []
    try:
        regex_rules = list(getattr(cfg, 'text_regex_replacements', []) or [])
    except Exception:
        regex_rules = []

    out: List[str] = []
    for t in (texts or []):
        s = normalize_ocr_text(t, aggressive)
        if base_map:
            s = _apply_simple_map(s, base_map)
        if regex_rules:
            s = _apply_regex_map(s, regex_rules)
        out.append(s)
    return out


def postprocess_translations(texts: List[str], cfg) -> List[str]:
    enabled = bool(getattr(cfg, 'text_postprocess_enabled', True))
    if not enabled:
        return [(_safe_str(t)).strip() for t in (texts or [])]

    aggressive = bool(getattr(cfg, 'text_postprocess_aggressive', False))
    out: List[str] = []
    for t in (texts or []):
        out.append(normalize_translated_text(t, aggressive))
    return out
